@off
REM Test Script for COAH. Create a temporary file with the inputs, each on a new line
5 w> temp_input.txt
adam beth amy diane ellen cara
bill diane beth amy cara ellen
carl beth ellen cara diane amy
dan amy diane cara beth ellen
eric beth diane amy ellen cara
amy eric adam bill dan carl
beth carl bill dan adam eric
cara bill carl dan eric adam
diane adam eric dan carl bill
ellen dan bill eric carl adam 
REM Run the python script, pass command-line arguments "arg1" ... "argn", 
REM and redirect the temporary file as standard input (< temp_input.txt)
python "./stable_matching.py" arg1 arg2 arg3 arg4 arg5 arg6 arg7 arg8 arg9 arg10 < temp_input.txt
REM Clean up the temporary file
del temp_input.txt
pause