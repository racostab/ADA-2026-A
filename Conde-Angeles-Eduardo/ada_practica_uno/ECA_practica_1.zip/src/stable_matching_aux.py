"""
Helper utilities for preparing and loading sample databases
used by the stable matching homework.
"""
import stable_matching as sm
from model import stable_matching_aux_dao as sm_dao
from stable_matching import print_message
from utils import chart_builder as smc
import timeit
_BEST_CASE=1 
_WORST_CASE=2
_RANDOM_CASE=0


def transform_data(db):
    """
    Convert a DB list of records into a list of names for stable_matching.
    Returns a list of names followed by the names of their preference.
    """
    universe = []
    tmp = []
    for item in db:
        tmp.append(item[sm._NAME])
        tmp.extend(item[sm._PROSPECTS])
        universe.append(tmp)
        tmp=[]
    return universe

def main_create_stablematching_sample_db(min_n=None, max_n=None):
    """
    This function is used to create the sample space
    of databases for the homework stable matching problem.
    The sample space consist of multiple files for N pairs
    For example:
            suitorsGaleShapleyFor_4.csv"
            prospectsGaleShapleyFor_4.csv"        
    Be sure to have enough disk space and be patient, create the sample space
    with high values of N it may take a lot of time.
    """
    global file_path
    if not min_n:
        min_n = 2
    if not max_n:
        max_n = 16
    for size in range(min_n, max_n + 1):
        #N = pow(2, size)
        N=size
        print_message(f"\n==> Preparing sample space for N={N}...")
        #best cases
        case=_BEST_CASE
        base_file_s = file_path + f"/best/suitorsGaleShapleyFor_{N}.csv"
        base_file_p = file_path + f"/best/prospectsGaleShapleyFor_{N}.csv"        
        sm_dao.create_sample_db(N, base_file_s, base_file_p, case)
        print_message(f"\n==> Sample space for best N={N} created successfully.")
        #worst cases
        case=_WORST_CASE
        base_file_s = file_path + f"/worst/suitorsGaleShapleyFor_{N}.csv"
        base_file_p = file_path + f"/worst/prospectsGaleShapleyFor_{N}.csv"        
        sm_dao.create_sample_db(N, base_file_s, base_file_p, case)
        print_message(f"\n==> Sample space for worst N={N} created successfully.")
        #random cases
        case=_RANDOM_CASE
        base_file_s = file_path + f"/random/suitorsGaleShapleyFor_{N}.csv"
        base_file_p = file_path + f"/random/prospectsGaleShapleyFor_{N}.csv"        
        sm_dao.create_sample_db(N, base_file_s, base_file_p, case)
        print_message(f"\n==> Sample space for random N={N} created successfully.")
        


def main_read_stablematching_sample_db(N, case=None):
    """
    According to N parameter, initialize the universe
    of values to test stable_matching
    """
    #set the values for db files related to N
    global file_path
    full_path=file_path+f'/'
    if case==_RANDOM_CASE:
        full_path=full_path+f'/random'
    elif case==_BEST_CASE:
        full_path=full_path+f'/best'
    elif case==_WORST_CASE:
        full_path=full_path+f'/worst'
        
    base_file_s = full_path + f"/suitorsGaleShapleyFor_{N}.csv"
    db = sm_dao.load_full_db_from_csv(base_file_s)
    suitors = transform_data(db)
    base_file_p = full_path + f"/prospectsGaleShapleyFor_{N}.csv"
    db = sm_dao.load_full_db_from_csv(base_file_p)
    prospects=transform_data(db)
    universe = []
    universe.extend(suitors)
    universe.extend(prospects)
    return universe

def stable_matching_measure_times(N, who_propose,case=None):
    """
    Core function to measure execution times
    """
    params = [N, who_propose]
    start_time_loadfiles = timeit.default_timer()    
    universe = main_read_stablematching_sample_db(N, case)
    end_time_loadfiles = timeit.default_timer()
    elapsed_time_loadfiles = end_time_loadfiles - start_time_loadfiles
    start_time = timeit.default_timer()
    sm.proceso(params, universe)
    end_time = timeit.default_timer()
    elapsed_time = end_time - start_time
    times=[elapsed_time,elapsed_time_loadfiles]
    return times    
    
def test_stable_matching(min_N, max_N, case=None):
    """
    Bunch of tests
    """
    who_propose='m'#the other valid value is w
    chart_matching_data=[]
    i=1    
    for j in range(min_N, max_N+1):
        #N = pow(2, j)
        N=j
        print_message(f"Stable matching for N={N}", True)
        times = stable_matching_measure_times(N, who_propose, case)
        print_message(f"For file={i} N={N} it takes {times[0]:.6f} seconds to match and {times[1]:.6f} seconds to load db-files in memory", True)
        chart_matching_data.append((N, times[0]))
        i=i+1
    global file_path
    full_path=file_path
    if case==_RANDOM_CASE:
        full_path=full_path+f'/random'
    elif case==_BEST_CASE:
        full_path=full_path+f'/best'
    elif case==_WORST_CASE:
        full_path=full_path+f'/worst'    
    chart_data_file = full_path + f"/chart_N_From_{min_N}_To_{max_N}.csv"
    sm_dao.write_data_chart_to_csv(chart_data_file, chart_matching_data)

def chart(min_N, max_N):
    """
    Chart from results previously saved
    """
    chart_data_file = file_path + f"/random/chart_N_From_{min_N}_To_{max_N}.csv"
    chart_matching_data = sm_dao.read_data_chart_from_csv(chart_data_file)
    smc.basic_chart(chart_matching_data)

def chart_comparison(min_N, max_N):
    """
    Chart comparison from results previously saved
    """
    global file_path
    full_path=file_path
    #_RANDOM_CASE
    full_path=full_path+f'/random'
    chart_data_file = full_path + f"/chart_N_From_{min_N}_To_{max_N}.csv"
    chart_matching_data_r = sm_dao.read_data_chart_from_csv(chart_data_file)
    
    #_BEST_CASE
    full_path=file_path
    full_path=full_path+f'/best'
    chart_data_file = full_path + f"/chart_N_From_{min_N}_To_{max_N}.csv"
    chart_matching_data_b = sm_dao.read_data_chart_from_csv(chart_data_file)
    
    #_WORST_CASE
    full_path=file_path
    full_path=full_path+f'/worst'
    chart_data_file = full_path + f"/chart_N_From_{min_N}_To_{max_N}.csv"
    chart_matching_data_w = sm_dao.read_data_chart_from_csv(chart_data_file)
    
    smc.plot_gs_comparison(chart_matching_data_b, chart_matching_data_r, chart_matching_data_w)


#global
#file_path = f"../dat"
file_path = f"../dat/wbr_l"

if __name__ == '__main__':
    n=1
    N=12
    #main_create_stablematching_sample_db(n, N)
    #test_stable_matching(n, N, _WORST_CASE)
    #test_stable_matching(n, N, _BEST_CASE)
    #test_stable_matching(n, N, _RANDOM_CASE)
    #chart_comparison(n, N)
    #chart(n, N)
    
    n=256
    N=512
    #crear base de datos
    #main_create_stablematching_sample_db(n, N)
    #probar algoritmo
    #test_stable_matching(n, N, _WORST_CASE)
    #test_stable_matching(n, N, _BEST_CASE)
    #test_stable_matching(n, N, _RANDOM_CASE)
    #chart_comparison(n, N)
    chart(n, N)
    
    n=600
    N=800
    #main_create_stablematching_sample_db(n, N)
    #test_stable_matching(n, N, _WORST_CASE)
    #test_stable_matching(n, N, _BEST_CASE)
    #test_stable_matching(n, N, _RANDOM_CASE)
    #chart_comparison(n, N)
    #chart(n, N)
    