from stable_matching import _ID, _NAME, _PROSPECTS, _ESTATUS, _MATCHED_ID, _MATCHED_NAME, Estatus
from stable_matching import print_message
from utils import random_numbers as ed_utils
from collections import deque
from itertools import islice
import csv
import os
import ast

"""
Create a sample pair of files (suitors and prospects) for stable matching problem, 
the files will be created in the path defined by file_path parameter, the size of files is
defined by the db_size parameter.
"""
def create_sample_db(db_size, suitors_file, prospects_file, case):
    create_db_file(db_size, suitors_file, case, False)
    create_db_file(db_size, prospects_file, case, True)

"""
Create a physical database file for stable matching problem.
"""
def create_db_file(size, csv_file_name, case, prospectsFlag):
    data_base = []
    size_of_block = 2500
    for i in range(1, size+1):
        id = i
        matching_preferences = None
        if case == 1:
            # --- BEST CASE ---
            # Cada i prefiere al i del otro grupo.
            # Usamos rotación: [i, i+1, ..., size, 1, ..., i-1]
            matching_preferences = [((i + j - 1) % size) + 1 for j in range(size)]
        elif case == 2:
            # --- WORST CASE ---
            if not prospectsFlag:
                # Suitors: Todos quieren primero al name_1, luego al name_2...
                matching_preferences = [j for j in range(1, size + 1)]
            else:
                # Prospects: Prefieren al suitor que propone al final.
                # Si los suitors proponen en orden 1, 2, 3...
                # El prospecto debe preferir al N, luego N-1... hasta el 1.
                matching_preferences = [j for j in range(size, 0, -1)]
        else:
            # --- RANDOM CASE ---
            matching_preferences = ed_utils.generate_random_int_n_array_between(size, 1, size)
        
        prospects = []
        for j in range(len(matching_preferences)):
            prospects.append(f"n_{matching_preferences[j]}")
        data_base.append({
                            _NAME: f"n_{id}",
                            _PROSPECTS: prospects
                        })
        if i%size_of_block == 0:
            persist_data_to_csv(csv_file_name, data_base)
            print_message(f"Persist database for size {size}... {i} entries created and saved into {csv_file_name}")  
            data_base = []
    #persist remaining if any
    persist_data_to_csv(csv_file_name, data_base)
    #just to be sure
    data_base = []

"""
Save data to csv file
"""
def persist_data_to_csv(file_name, data):
    #Create file if doesn't exist, appends if exist.
    if not data:
        print("No data to persist..")
        return
    file_exists = os.path.exists(file_name)
    try:
        with open(file_name, 'a', newline='') as f:
            #fieldnames = [_ID, _NAME, _PROSPECTS, _ESTATUS, _MATCHED_ID]
            fieldnames = [_NAME, _PROSPECTS]
            writer = csv.DictWriter(f, fieldnames=fieldnames)            
            # Write header only if file is new
            if not file_exists:
                writer.writeheader()
            for item in data:
                writer.writerow(item)
    except Exception as e:
        print(f"{file_name}.Error persisting data to CSV: {e}")



def load_full_db_from_csv(file_name):
    #global _DB_SUITORS
    #global _DB_PROSPECTS
    db = []
    try:
        with open(file_name, 'r') as f:
            reader = csv.DictReader(f)
            i=1
            for row in reader:
                #print_message(f"Reading row: {row}")
                # Parse prospects from string representation to list
                prospects = ast.literal_eval(row[_PROSPECTS])
                # Convert matched_id to appropriate type (None if empty)
                #matched_id = None if row[_MATCHED_ID] == '' else int(row[_MATCHED_ID])
                db.append({
                            #_ID: int(row[_ID]), 
                            _NAME: row[_NAME],
                            _PROSPECTS: prospects,
                            #_ESTATUS: int(row[_ESTATUS]),
                            #_MATCHED_ID: matched_id

                })
                if i%100==0:
                    print_message(f"Leyendo {i} de ")
                i=i+1
        #print(db)
        return db
    except Exception as e:
        print(f"Error reading CSV file: {e}")


"""
Save data to make charts
"""
def write_data_chart_to_csv(file_name, data):
    #Create file if doesn't exist, appends if exist.
    if not data:
        print("No data to persist..")
        return
    file_exists = os.path.exists(file_name)
    try:
        with open(file_name, 'a', newline='') as f:
            # Create a CSV writer object
            writer = csv.writer(f)
            writer.writerow(("N","TimeInSeconds"))
            # Write all the rows at once
            writer.writerows(data)
    except Exception as e:
        print(f"{file_name}.Error persisting data to CSV: {e}")

def read_data_chart_from_csv(file_name):
    data=[]
    with open(file_name, mode='r', newline='') as file:
        reader = csv.DictReader(file)
        for row in reader:
            data.append((int(row['N']),float(row['TimeInSeconds'])))
    return data