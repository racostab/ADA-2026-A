"""
To generate random number 
"""
import random

def generate_random_int_between(j,k):
    random_int = random.randint(j, k)
    return random_int

def generate_random_int_n_array_between(n, j, k):
    #create an fill an array with values between j and k
    elements = list(range(j, k+1))
    #generate a list of n elements between j and k without repetition
    random_int = random.sample(elements, n)
    return random_int

if __name__ == "__main__":
    n=10; i=1; j=10
    print(f"Random integer between 1 and 10: {generate_random_int_between(i, j)}")
    print(f"{n} random elements between {i} and {j}: {generate_random_int_n_array_between(n, i, j)}")
    print(f"{n} random elements between {i} and {j}: {generate_random_int_n_array_between(n, i, j)}")
    