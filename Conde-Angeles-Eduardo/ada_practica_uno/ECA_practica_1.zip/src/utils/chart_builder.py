import matplotlib.pyplot as plt

def basic_chart(chart_data):
    # Define your data
    #x_values = [1, 2, 3, 4]
    #y_values = [1, 4, 2, 3]
    x_values = []
    y_values = []
    for item in chart_data:
        print(f"x={item[0]},y={item[1]}")
        x_values.append(item[0])
        y_values.append(item[1])
    # Plot the data
    plt.plot(x_values, y_values) #
    # Add labels and a title for clarity
    plt.xlabel('Cardinalidad N (Número de Parejas)')
    plt.ylabel('Tiempo de Ejecución (Segundos)')
    plt.title('Análisis de Rendimiento: Algoritmo Gale-Shapley')
    plt.xscale('log', base=2) 
    
    # Display the chart
    plt.show()

def plot_gs_comparison(best_results, random_results, worst_results):
    """
    Grafica las tres curvas de forma continua.
    Cada input es una lista de resultados
    """
    # 1. Preparar los datos (Aseguramos que estén ordenados por N)
    best_results.sort()
    random_results.sort()
    worst_results.sort()

    # Extraer ejes X (N) y Y (Tiempo)
    x_b, y_b = zip(*best_results)
    x_r, y_r = zip(*random_results)
    x_w, y_w = zip(*worst_results)

    # 2. Crear la figura
    plt.figure(figsize=(12, 7))

    # 3. Graficar líneas continuas
    # Usamos 'linewidth' para la continuidad y 'marker' solo para resaltar los puntos probados
    plt.plot(x_b, y_b, label='Mejor Caso (O(N))', color='#2ecc71', marker='o', linewidth=2)
    plt.plot(x_r, y_r, label='Caso Aleatorio (O(N log N))', color='#3498db', marker='^', linewidth=2)
    plt.plot(x_w, y_w, label='Peor Caso (O(N²))', color='#e74c3c', marker='s', linewidth=2)

    # 4. Configuración de Escalas
    # Para ver con mas claridad el caso cuadrativo
    #plt.xscale('log', base=2)
    #plt.yscale('log')

    # 5. Estética y Etiquetas
    plt.title('Análisis de Rendimiento: Algoritmo Gale-Shapley', fontsize=14, pad=20)
    plt.xlabel('Cardinalidad N (Número de Parejas)', fontsize=12)
    plt.ylabel('Tiempo de Ejecución (Segundos)', fontsize=12)
    
    plt.grid(True, which="both", linestyle='--', alpha=0.5)
    plt.legend(fontsize=11)
    
    # Agregamos anotación de ayuda
    plt.tight_layout()    
    # Mostrar
    plt.show()

if __name__ == "__main__":
    basic_chart()
