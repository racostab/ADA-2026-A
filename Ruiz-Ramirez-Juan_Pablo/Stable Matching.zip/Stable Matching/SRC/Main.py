import time
import matplotlib.pyplot as plt
import csv

from AlgoritmoEmparejamiento import gale_shapley, leer_archivo


tiempos = []
print("Iniciando programa")
for i in range(1,30):
    print(f"Procesando archivo {i}...")
    inicio_lectura = time.perf_counter()
    ruta = rf"C:\Users\PLANETMEDIA\Documents\Python\DAT\Datos de Entrada\archivo_{i}_n{i**2}.txt"
    N,quien_propone,hombres, mujeres, preferencias_m, preferencias_w = leer_archivo(ruta)
    fin_lectura = time.perf_counter()

    inicio_emparejamiento = time.perf_counter()
    resultados = gale_shapley(hombres, mujeres, preferencias_m, preferencias_w)
    fin_emparejamiento = time.perf_counter()

    inicio_impresion = time.perf_counter()
    for hombre in hombres:
        print(f"{hombre} {resultados[hombre]}")
    fin_impresion = time.perf_counter()

    Tiempo1 = fin_lectura - inicio_lectura
    Tiempo2 = fin_emparejamiento - inicio_emparejamiento
    Tiempo3 = fin_impresion - inicio_impresion

    tiempos.append((i,i**2,Tiempo1,Tiempo2,Tiempo3))

valores_N = [t[1] for t in tiempos]
tiempo_lectura = [t[2] for t in tiempos]
tiempo_emparejamiento = [t[3] for t in tiempos]
tiempo_impresion = [t[4] for t in tiempos]


with open(rf"C:\Users\PLANETMEDIA\Documents\Python\DAT\Tiempos.csv", "w", newline='', encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(['Archivo', 'N', 'Lectura', 'Emparejamiento', 'Impresion'])
    for t in tiempos:
        writer.writerow(t)

plt.xscale('log')
plt.yscale('log')
plt.plot(valores_N, tiempo_lectura, label='Lectura')
plt.plot(valores_N, tiempo_emparejamiento, label='Emparejamiento')
plt.plot(valores_N, tiempo_impresion, label='Impresion')
plt.xlabel('N')
plt.ylabel('Tiempo (segundos)')
plt.title('Tiempos de ejecución Gale-Shapley')
plt.legend()
plt.show()



print("FIN del programa")

