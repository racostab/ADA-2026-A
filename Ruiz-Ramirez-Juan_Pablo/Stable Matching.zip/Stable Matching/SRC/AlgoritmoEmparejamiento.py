def gale_shapley(hombres, mujeres, preferencias_m, preferencias_w):
   pareja_de_w = {}

   siguiente_propuesta = {hombre: 0 for hombre in hombres}
   while True:
      m = None
      for m in hombres: 
         if m not in pareja_de_w.values() and siguiente_propuesta[m] < len(preferencias_m[m]): 
            break
      else:
            m = None
      if m is None:
          break
      # resto del algoritmo
      w = preferencias_m[m][siguiente_propuesta[m]]
      siguiente_propuesta[m] += 1
      if w not in pareja_de_w:
         pareja_de_w[w] = m
      else:
         m_actual = pareja_de_w[w]
         if (preferencias_w[w].index(m) < preferencias_w[w].index(m_actual)):
            pareja_de_w[w] = m
   pareja_invertida = {hombre: mujer for mujer, hombre in pareja_de_w.items()}
   return pareja_invertida


def leer_archivo(ruta):
    with open(ruta, 'r') as f:
        lineas = f.readlines()
    N, quien_propone = lineas[0].strip().split()
    N = int(N)
    # leer hombres desde lineas[1] hasta lineas[N]
    hombres = []
    preferencias_m = {}    
    for i in range(N):
        partes = lineas[i+1].strip().split()
        hombre = partes[0]
        preferencias_m[hombre] = partes[1:]
        hombres.append(hombre)
    # leer mujeres desde lineas[N+1] hasta lineas[2*N]
    mujeres = []
    preferencias_w = {}
    for j in range(N):
        partes = lineas[j+N+1].strip().split()
        mujer = partes[0]
        preferencias_w[mujer] = partes[1:]
        mujeres.append(mujer)
    
    return N, quien_propone, hombres, mujeres, preferencias_m, preferencias_w

if __name__ == "__main__":

   ruta= input()
   N, quien_propone, hombres, mujeres, preferencias_m, preferencias_w = leer_archivo(ruta)  

   if quien_propone == 'w': 
     resultado = gale_shapley(mujeres, hombres, preferencias_w, preferencias_m) 
     resultado = {hombre: mujer for mujer, hombre in resultado.items()}
   else: 
      resultado = gale_shapley(hombres, mujeres, preferencias_m, preferencias_w)

   for hombre in hombres:
       print(f"{hombre} {resultado[hombre]}")


