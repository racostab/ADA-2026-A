
import random
import os
directorio = r"C:\Users\PLANETMEDIA\Documents\Python\DAT\Datos de Entrada"
os.makedirs(directorio, exist_ok=True)

print("----------")
print("Archivos guardados en: ",directorio)
print("----------")

random.seed(42)

def generar_preferencias(N):
    """
    Genera listas de preferencias aleatorias para n personas.
    Cada persona tiene una lista de preferencia con todos los miembros del otro grupo.
    """
    preferencias = {}
    for h in range(N):
        # Crear lista de preferencias (permutación aleatoria de 0 a n-1)
        prefs = list(range(N,2*N))
        random.shuffle(prefs)
        preferencias[str(h)] = prefs

    for m in range(N,2*N):
        # Crear lista de preferencias (permutación aleatoria de 0 a n-1)
        prefs = list(range(N))
        random.shuffle(prefs)
        preferencias[str(m)] = prefs
    return preferencias


def generar_archivo(N, quien_propone, ruta, preferencias):
    with open(ruta, 'w', encoding='utf-8') as f:
            f.write(f"{N} {quien_propone}\n")
            # Preferencias de los hombres
            for h in range(N):
               prefs = " ".join(str(x) for x in preferencias[str(h)])
               f.write(f"{h} {prefs}\n")

            # Preferencias de las mujeres
            for m in range(N,2*N):
               prefs = " ".join(str(x) for x in preferencias[str(m)])
               f.write(f"{m} {prefs}\n")

valores_N = [i**2 for i in range(1, 30)]
for i, N in enumerate(valores_N, 1):
    preferencias = generar_preferencias(N)
    ruta = os.path.join(directorio, f"archivo_{i}_n{N}.txt")
    generar_archivo(N, 'm', ruta, preferencias)