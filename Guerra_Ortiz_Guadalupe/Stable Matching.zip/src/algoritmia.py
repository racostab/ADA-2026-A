"""
GGUERRA
"""
import random
import os
import time
from two import gale_shapley  # Asegúrate de tener este módulo disponible
import csv
import matplotlib.pyplot as plt
#import platform

# ================================ Configuración de debug
debug = True
def impresion(*args, **kwargs):
    if debug:
        print(*args, **kwargs)

# ================================ Funciones auxiliares p. conversión de tiempo
def seconds_to_timecode(seconds, fps=30): 
    """Convierte segundos a HH:MM:SS:FF"""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    frames = round((seconds - int(seconds)) * fps)

    if frames >= fps:
        frames = 0
        secs += 1
        if secs >= 60:
            secs = 0
            minutes += 1
            if minutes >= 60:
                minutes = 0
                hours += 1

    return f"{hours:02d}:{minutes:02d}:{secs:02d}:{frames:02d}"

# ================================ Generación de archivos de entrada
def generar_archivos_entrada(N, carpeta):
    """
    Genera un archivo con preferencias aleatorias para N hombres y N mujeres
    """
    inicio = time.perf_counter()
    hombres = [f"H{i}" for i in range(1, N+1)]
    mujeres = [f"M{i}" for i in range(1, N+1)]

    nombre_archivo = os.path.join(carpeta, f"entrada_{N}.txt")
    with open(nombre_archivo, "w") as f:
        # Preferencias de hombres
        for h in hombres:
            prefs = mujeres[:]
            random.shuffle(prefs)
            f.write(f"{h}: {' '.join(prefs)}\n")
        # Preferencias de mujeres
        for m in mujeres:
            prefs = hombres[:]
            random.shuffle(prefs)
            f.write(f"{m}: {' '.join(prefs)}\n")

    fin = time.perf_counter()
    t_escritura = fin - inicio
    timecode_escritura = seconds_to_timecode(t_escritura, fps=240)
    impresion(f"N={N} → Escritura de archivo: {timecode_escritura}")
    return t_escritura

def generar_m_archivos(total_archivos, N_inicial, incremento, carpeta="archivos_entrada"):
    os.makedirs(carpeta, exist_ok=True)
    tiempos_escritura = []
    for i in range(total_archivos):
        N = N_inicial + i * incremento
        t = generar_archivos_entrada(N, carpeta)
        tiempos_escritura.append((N, t))
    return tiempos_escritura

# ================================ Lectura de archivos
def leer_archivo(ruta_archivo, id_archivo):
    inicio = time.perf_counter()
    hombres_prefs = {}
    mujeres_prefs = {}

    with open(ruta_archivo, "r") as f:
        lineas = [line.strip() for line in f if line.strip() != ""]

    mitad = len(lineas) // 2
    for i, linea in enumerate(lineas):
        llave, valor = linea.split(":")
        llave = llave.strip()
        valor_lista = valor.strip().split()
        if i < mitad:
            hombres_prefs[llave] = valor_lista
        else:
            mujeres_prefs[llave] = valor_lista

    fin = time.perf_counter()
    t_lectura = fin - inicio
    timecode_lect = seconds_to_timecode(t_lectura, fps=240)
    impresion(f"N={id_archivo} → Lectura archivo: {timecode_lect}")
    return hombres_prefs, mujeres_prefs, t_lectura

# ================================ Guardado de tiempos
def guardar_tiempos(nombre_archivo, N, timecode_escritura, timecode_lect, t_algoritmo):
    archivo_existe = os.path.exists(nombre_archivo)
    with open(nombre_archivo, "a") as f:
        if not archivo_existe:
            f.write("N,tiempo_escritura,tiempo_lectura,tiempo_algoritmo\n")
        f.write(f"{N},{timecode_escritura},{timecode_lect},{t_algoritmo}\n")

# ================================ Lectura de tiempos para graficar.
def leer_tiempos(ruta):
    impresion(f"Leyendo tiempos desde: {ruta}")
    tiempos = []
    with open(ruta, newline='') as archivo:
        lector = csv.reader(archivo)
        next(lector)  # Saltar encabezado si existe
        for fila in lector:
            N = int(fila[0])
            t_write = float(fila[1])
            t_read = float(fila[2])
            t_algo = float(fila[3])
            tiempos.append((N, t_write, t_read, t_algo))
    return tiempos

# ================================ Graficación.
def plot_times(tiempos):
    N = [x[0] for x in tiempos]
    t_write = [x[1] for x in tiempos]
    t_read = [x[2] for x in tiempos]
    t_algo = [x[3] for x in tiempos]

    plt.plot(N, t_write, label="Escritura")
    plt.plot(N, t_read, label="Lectura")
    plt.plot(N, t_algo, label="Algoritmo")
    plt.xlabel("N - Cardinalidad")
    plt.ylabel("Tiempo (segundos)")
    plt.title("Rendimiento Emparejamiento Estable")
    plt.legend()
    plt.show()

# ================================ maIN
def second_main(N):
    total_archivos = 100
    archivo_tiempos = "tiempos.csv"
    N_inicial = N
    incremento = 1
    carpeta = "archivos_entrada"

    impresion(f"Generación de archivos: N inicial={N_inicial}, incremento={incremento}")
    generar_m_archivos(total_archivos, N_inicial, incremento, carpeta)

    tiempos_completos = []

    for i in range(total_archivos):
        id_archivo = N_inicial + i * incremento
        ruta = os.path.join(carpeta, f"entrada_{id_archivo}.txt")
        impresion(f"Procesando archivo: {ruta}")

        hombres, mujeres, t_lectura = leer_archivo(ruta, id_archivo)

        # Ejecutar Gale-Shapley
        resultado, t_emparejamiento = gale_shapley(hombres, mujeres)
        timecode_alg = seconds_to_timecode(t_emparejamiento, fps=240)
        impresion(f"N={id_archivo} → Tiempo emparejamiento: {timecode_alg}")

        # Guardar en CSV
        guardar_tiempos(archivo_tiempos, id_archivo, 0, t_lectura, t_emparejamiento)

        # Guardar para graficar
        tiempos_completos.append((id_archivo, 0, t_lectura, t_emparejamiento))

        # Graficar resultados
        #tiempos = leer_tiempos(archivo_tiempos)
        #plot_times(tiempos)

# ================================ GRAFICICAR
def leer_columna_0(archivo_csv):
    columna_0 = []

    with open(archivo_csv, newline='') as archivo:
        lector = csv.reader(archivo)

        for fila in lector:
            if len(fila) > 0:  # evitar errores si hay filas vacías
                columna_0.append(fila[0])
                impresion(f"lector: {fila[0]}")
                next(lector)  

        for fila in lector:
            if len(fila) > 0:  # evitar errores si hay filas vacías
                columna_0.append(fila[0])

    return columna_0

# ================================ MAIN pruebas para graficar
if __name__ == "__mainC__":
    ruta = "tiempos.csv"
    carpeta_entrada = r"C:\code\Algoritmia\test\Pruebas\archivos_entrada"
    tiempos = leer_tiempos(ruta)
    plot_times(tiempos)

# ================================ MAIN
if __name__ == "__main__":
    N = int(input("Ingrese el valor de N (entero positivo): "))
    ruta = "tiempos.csv"
    carpeta_entrada = r"C:\code\Algoritmia\test\Pruebas\archivos_entrada"

    # 1️ Verificar si hay archivos de entrada
    ruta_archivo = os.path.join(carpeta_entrada, f"entrada_{N}.txt")
    if os.path.exists(ruta_archivo):
        #impresion(f"Existen archivos de entrada para N={N} encontrado: {ruta_archivo}")
        tiempos = leer_tiempos(ruta)
        plot_times(tiempos)

    else:
        impresion(f"No existe el archivo de entrada para N={N}. Ejecutando second_main(N) para generarlo.")
        second_main(N)